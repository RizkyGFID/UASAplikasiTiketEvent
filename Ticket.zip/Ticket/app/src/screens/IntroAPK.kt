package com.<your>.<application>
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.view.View
import com.bumptech.glide.Glide
class IntroAPK : AppCompatActivity() {
	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		setContentView(R.layout.activity_intro_a_p_k)
		Glide.with(this).load("https://storage.googleapis.com/tagjs-prod.appspot.com/v1/YGjojpOZiH/132xvpqi_expires_30_days.png").into(findViewById(R.id.rundefined))
	}
}