package com.example.ticket;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

// Import library QR
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;

public class MyTicketActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_ticket);

        // 1. Inisialisasi View
        CardView cardTicket = findViewById(R.id.cardTicket);
        TextView tvNoTicket = findViewById(R.id.tvNoTicket);
        TextView tvTicketType = findViewById(R.id.tvTicketType);
        ImageView imgTicketQR = findViewById(R.id.imgTicketQR); // ImageView yang baru diedit

        // --- SIMULASI DATA (Nanti bisa diganti database) ---
        boolean userSudahBeli = true; // Ubah jadi false untuk tes tampilan kosong
        String jenisTiket = "VIP (ALL ACCESS)";
        // ---------------------------------------------------

        if (userSudahBeli) {
            // Tampilkan Tiket
            cardTicket.setVisibility(View.VISIBLE);
            tvNoTicket.setVisibility(View.GONE);
            tvTicketType.setText(jenisTiket);

            // 2. GENERATE QR CODE TIKET
            // Isi QR Code unik untuk tiket ini
            String contentQR = "TICKET_VALID|2025|" + jenisTiket + "|USER_ID_001";

            try {
                MultiFormatWriter multiFormatWriter = new MultiFormatWriter();
                // Ukuran 400x400 pixel
                BitMatrix bitMatrix = multiFormatWriter.encode(contentQR, BarcodeFormat.QR_CODE, 400, 400);
                BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
                Bitmap bitmap = barcodeEncoder.createBitmap(bitMatrix);

                // Pasang gambar QR ke ImageView
                imgTicketQR.setImageBitmap(bitmap);

            } catch (WriterException e) {
                e.printStackTrace();
            }

        } else {
            // Sembunyikan Tiket
            cardTicket.setVisibility(View.GONE);
            tvNoTicket.setVisibility(View.VISIBLE);
        }
    }
}
