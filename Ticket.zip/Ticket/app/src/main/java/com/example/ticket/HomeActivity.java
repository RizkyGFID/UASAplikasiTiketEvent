package com.example.ticket;

import android.content.DialogInterface; // Tambahan untuk Pop-up
import android.content.Intent;
import android.content.SharedPreferences; // Tambahan untuk simpan nama
import android.os.Bundle;
import android.text.InputType; // Tambahan untuk tipe input
import android.view.View;
import android.widget.EditText; // Tambahan untuk kotak isian
import android.widget.TextView; // Tambahan untuk TextView
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog; // Tambahan untuk Pop-up
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class HomeActivity extends AppCompatActivity {

    // Deklarasi variabel di sini agar bisa diakses semua fungsi
    TextView tvWelcome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // Inisialisasi View
        tvWelcome = findViewById(R.id.tvWelcome); // Teks "Halo, User!"
        // ... kode yang sudah ada ...
        CardView menuInfo = findViewById(R.id.menuInfo);
        CardView menuLogout = findViewById(R.id.menuLogout);

        // --- TAMBAHAN BARU ---
        CardView menuInfoApp = findViewById(R.id.menuInfoApp);
        // ---------------------

        CardView cardBanner = findViewById(R.id.cardBanner);
        CardView menuMyTicket = findViewById(R.id.menuMyTicket);

        // --- 1. CEK NAMA YANG TERSIMPAN ---
        // Saat aplikasi dibuka, cek apakah ada nama yang disimpan sebelumnya
        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        String namaSimpanan = prefs.getString("nama_user", "User"); // Default "User"
        tvWelcome.setText("Halo, " + namaSimpanan + "!");


        // --- 2. FITUR GANTI NAMA (POP-UP) ---
        // Kalau teks "Halo, ..." diklik, muncul kotak ganti nama
        tvWelcome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                munculkanDialogGantiNama();
            }
        });


        // Logika Klik Banner
        if (cardBanner != null) {
            cardBanner.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(HomeActivity.this, EventDetailActivity.class);
                    startActivity(intent);
                }
            });
        }

        // Logika Tombol TIKET SAYA
        if (menuMyTicket != null) {
            menuMyTicket.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(HomeActivity.this, MyTicketActivity.class);
                    startActivity(intent);
                }
            });
        }

        // Tombol LOKASI
        if (menuInfo != null) {
            menuInfo.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(HomeActivity.this, LocationActivity.class);
                    startActivity(intent);
                }
            });
        }

        // --- LOGIKA TOMBOL INFORMASI (Baru) ---
        if (menuInfoApp != null) {
            menuInfoApp.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(HomeActivity.this, InfoActivity.class);
                    startActivity(intent);
                }
            });
        }


        // Tombol LOGOUT
        if (menuLogout != null) {
            menuLogout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(HomeActivity.this, LoginActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finish();
                    Toast.makeText(HomeActivity.this, "Berhasil Keluar", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    // --- FUNGSI MEMBUAT POP-UP ---
    private void munculkanDialogGantiNama() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Ganti Nama Panggilan");

        // Bikin kotak isian (EditText)
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        input.setHint("Masukkan nama baru...");
        builder.setView(input);

        // Tombol Simpan
        builder.setPositiveButton("Simpan", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String namaBaru = input.getText().toString();

                if (!namaBaru.isEmpty()) {
                    // 1. Ganti teks di layar
                    tvWelcome.setText("Halo, " + namaBaru + "!");

                    // 2. Simpan ke memori HP (biar gak hilang pas ditutup)
                    SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
                    SharedPreferences.Editor editor = prefs.edit();
                    editor.putString("nama_user", namaBaru);
                    editor.apply();

                    Toast.makeText(HomeActivity.this, "Nama berhasil diganti!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Tombol Batal
        builder.setNegativeButton("Batal", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();
    }
}
