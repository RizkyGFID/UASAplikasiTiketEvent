package com.example.ticket;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class TicketSelectionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ticket_selection);

        // 1. Inisialisasi Tombol dari Layout
        Button btnRegular = findViewById(R.id.btnRegular);
        Button btnRegular4Hari = findViewById(R.id.btnRegular4Hari);
        Button btnVvip = findViewById(R.id.btnVvip);

        // 2. Logika Tombol REGULAR (Rp 70.000)
        btnRegular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pindahKePembayaran("Tiket Regular", "Rp 70.000");
            }
        });

        // 3. Logika Tombol REGULAR 4 HARI (Rp 230.000)
        btnRegular4Hari.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pindahKePembayaran("Tiket Regular 4 Hari", "Rp 230.000");
            }
        });

        // 4. Logika Tombol VIP (Rp 500.000)
        btnVvip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pindahKePembayaran("Tiket VIP (All Access)", "Rp 500.000");
            }
        });
    }

    // Fungsi khusus untuk pindah halaman sambil bawa data
    private void pindahKePembayaran(String namaTiket, String hargaTiket) {
        Intent intent = new Intent(TicketSelectionActivity.this, PaymentActivity.class);

        // Masukkan data ke dalam paket "Intent"
        intent.putExtra("TICKET_NAME", namaTiket);
        intent.putExtra("TICKET_PRICE", hargaTiket);

        startActivity(intent);
    }
}
