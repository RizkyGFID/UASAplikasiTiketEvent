package com.example.ticket;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import org.osmdroid.config.Configuration;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider;
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay;

public class LocationActivity extends AppCompatActivity {

    private MapView map;
    private MyLocationNewOverlay locationOverlay; // Overlay untuk titik biru lokasi user
    private static final int REQUEST_CODE_LOCATION = 1; // Kode unik permintaan izin

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 1. Konfigurasi OSM
        Context ctx = getApplicationContext();
        Configuration.getInstance().load(ctx, PreferenceManager.getDefaultSharedPreferences(ctx));

        setContentView(R.layout.activity_location);

        // 2. Setup Peta Dasar
        map = findViewById(R.id.map);
        map.setTileSource(TileSourceFactory.MAPNIK);
        map.setMultiTouchControls(true);
        map.getController().setZoom(18.0);

        // Set titik default (misal Monas) jika GPS belum aktif
        GeoPoint startPoint = new GeoPoint(-6.175392, 106.827153);
        map.getController().setCenter(startPoint);

        // 3. CEK DAN MINTA IZIN LOKASI
        checkLocationPermission();

        // 4. Tombol "Lihat Lokasi Saya" (Untuk memusatkan kembali ke user)
        Button btnCenter = findViewById(R.id.btnCenter);
        btnCenter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (locationOverlay != null && locationOverlay.getMyLocation() != null) {
                    map.getController().animateTo(locationOverlay.getMyLocation());
                } else {
                    Toast.makeText(LocationActivity.this, "Sedang mencari lokasi...", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // --- FUNGSI IZIN & LOKASI ---

    private void checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // Jika izin belum diberikan, minta izin ke user (Muncul Pop-up Android)
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_CODE_LOCATION);
        } else {
            // Jika sudah diizinkan, aktifkan fitur lokasi
            aktifkanLokasiUser();
        }
    }

    // Fungsi ini dipanggil otomatis setelah user klik "Allow" atau "Deny"
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CODE_LOCATION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // User klik "Allow"
                Toast.makeText(this, "Izin diberikan, menampilkan lokasi...", Toast.LENGTH_SHORT).show();
                aktifkanLokasiUser();
            } else {
                // User klik "Deny"
                Toast.makeText(this, "Izin ditolak. Peta hanya menampilkan lokasi default.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void aktifkanLokasiUser() {
        // Menambahkan Overlay (Titik Biru) lokasi user
        locationOverlay = new MyLocationNewOverlay(new GpsMyLocationProvider(this), map);
        locationOverlay.enableMyLocation(); // Aktifkan GPS
        locationOverlay.enableFollowLocation(); // Peta otomatis mengikuti user
        map.getOverlays().add(locationOverlay);

        // Refresh peta
        map.invalidate();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (map != null) map.onResume();
        if (locationOverlay != null) locationOverlay.enableMyLocation();
    }

    @Override
    public void onPause() {
        super.onPause();
        if (map != null) map.onPause();
        if (locationOverlay != null) locationOverlay.disableMyLocation();
    }
}
