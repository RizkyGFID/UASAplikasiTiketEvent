package com.example.ticket;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.zxing.BarcodeFormat; // Import Library ZXing
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder; // Import Encoder

public class PaymentActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        // 1. Ambil Data dari Halaman Sebelumnya (TicketSelectionActivity)
        String ticketName = getIntent().getStringExtra("TICKET_NAME");
        String ticketPrice = getIntent().getStringExtra("TICKET_PRICE");

        // Jika data kosong (untuk testing langsung run), kasih default
        if (ticketName == null) ticketName = "Tiket Demo";
        if (ticketPrice == null) ticketPrice = "Rp 0";

        // 2. Set Teks di Layout
        TextView tvTicketName = findViewById(R.id.tvTicketName);
        TextView tvTicketPrice = findViewById(R.id.tvTicketPrice);
        TextView tvTotalPrice = findViewById(R.id.tvTotalPrice);
        ImageView imgQRCode = findViewById(R.id.imgQRCode); // Gambar QR
        Button btnPayNow = findViewById(R.id.btnPayNow);

        tvTicketName.setText(ticketName);
        tvTicketPrice.setText(ticketPrice);
        tvTotalPrice.setText(ticketPrice);

        // 3. GENERATE QR CODE DINAMIS
        // Kita gabungkan Nama + Harga jadi satu string unik untuk isi QR Code
        String contentQR = "PAYMENT_ID:12345|" + ticketName + "|" + ticketPrice;

        try {
            // Proses pembuatan gambar QR
            MultiFormatWriter multiFormatWriter = new MultiFormatWriter();
            BitMatrix bitMatrix = multiFormatWriter.encode(contentQR, BarcodeFormat.QR_CODE, 500, 500);

            BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
            Bitmap bitmap = barcodeEncoder.createBitmap(bitMatrix);

            // Tampilkan gambar ke ImageView
            imgQRCode.setImageBitmap(bitmap);

        } catch (WriterException e) {
            e.printStackTrace();
        }

        // 4. Tombol Bayar
        btnPayNow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Simpan status pembelian (bisa pakai SharedPreference/Database nanti)
                Toast.makeText(PaymentActivity.this, "Pembayaran Berhasil!", Toast.LENGTH_LONG).show();

                // Pindah ke halaman Tiket Saya (atau balik ke Home)
                Intent intent = new Intent(PaymentActivity.this, HomeActivity.class);
                // Menghapus history agar pas di-Back tidak balik ke payment
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                finish();
            }
        });
    }
}
