package com.example.ticket;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class InfoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // --- INI KUNCI AGAR TIDAK CRASH ---
        // Pastikan nama layout di dalam kurung ini benar (activity_info)
        setContentView(R.layout.activity_info);
    }
}

