package com.example.ticket;

import android.content.Intent; // Jangan lupa import ini
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class EventDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_detail);

        Button btnBuyTicket = findViewById(R.id.btnBuyTicket);

        // Ubah aksi klik di sini:
        btnBuyTicket.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Pindah ke halaman Pilih Tiket
                Intent intent = new Intent(EventDetailActivity.this, TicketSelectionActivity.class);
                startActivity(intent);
            }
        });
    }
}
