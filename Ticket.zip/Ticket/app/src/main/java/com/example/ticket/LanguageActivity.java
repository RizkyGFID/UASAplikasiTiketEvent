package com.example.ticket;

import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import java.util.Locale;

public class LanguageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_language);

        CardView cardIndo = findViewById(R.id.cardIndo);
        CardView cardEnglish = findViewById(R.id.cardEnglish);

        // Tambahan tombol baru
        CardView cardArabic = findViewById(R.id.cardArabic);
        CardView cardJapanese = findViewById(R.id.cardJapanese);

        // 1. INDONESIA
        cardIndo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setAppLocale("in");
                pindahKeLogin();
            }
        });

        // 2. INGGRIS
        cardEnglish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setAppLocale("en");
                pindahKeLogin();
            }
        });

        // 3. ARAB (BARU)
        cardArabic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setAppLocale("ar"); // Kode bahasa Arab
                pindahKeLogin();
            }
        });

        // 4. JEPANG (BARU)
        cardJapanese.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setAppLocale("ja"); // Kode bahasa Jepang
                pindahKeLogin();
            }
        });
    }

    private void setAppLocale(String localeCode) {
        Resources res = getResources();
        DisplayMetrics dm = res.getDisplayMetrics();
        Configuration conf = res.getConfiguration();
        conf.setLocale(new Locale(localeCode.toLowerCase()));
        res.updateConfiguration(conf, dm);

        // Pesan konfirmasi (Optional)
        String msg = "Bahasa diubah: " + localeCode;
        if(localeCode.equals("ar")) msg = "اللغة المختارة: العربية";
        if(localeCode.equals("ja")) msg = "言語が変更されました";

        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    private void pindahKeLogin() {
        Intent intent = new Intent(LanguageActivity.this, LoginActivity.class);
        startActivity(intent);
        finish();
    }
}
