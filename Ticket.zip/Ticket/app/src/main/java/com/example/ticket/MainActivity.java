package com.example.ticket;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 1. Inisialisasi View
        ImageView imgLogo = findViewById(R.id.imageView);
        TextView tvTitle = findViewById(R.id.textView2);

        // 2. Load Animasi dari folder res/anim
        Animation animBottom = AnimationUtils.loadAnimation(this, R.anim.bottom_to_top);
        Animation animFade = AnimationUtils.loadAnimation(this, R.anim.fade_in);

        // 3. Jalankan Animasi
        imgLogo.startAnimation(animBottom); // Logo bergerak dari bawah ke atas
        tvTitle.startAnimation(animFade);   // Teks muncul perlahan

        // 4. Timer Pindah Halaman (Tetap sama seperti sebelumnya)
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                // Arahkan ke LanguageActivity dulu
                Intent intent = new Intent(MainActivity.this, LanguageActivity.class);
                startActivity(intent);
                finish();
            }
        }, 3000); // 3 Detik
    }
}
